Every human don't have the same height no ? So why monsters do ? 

This mod make monsters spawn with a random size, that you can configure with LethalLib !